const API_BASE = "http://localhost:5003";
const socket = io(API_BASE);
async function addProperty() {
    const prop = {
        title: document.getElementById("title").value,
        location: document.getElementById("location").value,
        price: parseFloat(document.getElementById("price").value),
        image_url: document.getElementById("image_url").value
    };
    const res = await fetch(`${API_BASE}/admin/add_property`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(prop)
    });
    const data = await res.json();
    alert("Property added!");
    renderProperties([data]);
}
function renderProperties(properties) {
    const container = document.getElementById("property-list");
    properties.forEach(p => {
        const card = document.createElement("div");
        card.className = "bg-white p-4 rounded-xl shadow-md";
        card.innerHTML = `
            <img src="${p.image_url}" class="rounded-xl mb-2">
            <h3 class="font-bold text-lg">${p.title}</h3>
            <p class="text-gray-600">${p.location}</p>
            <p class="font-semibold">$${p.price}</p>
            <button onclick="deleteProperty(${p.id})" class="bg-red-600 text-white px-2 py-1 rounded mt-2">Delete</button>
        `;
        container.appendChild(card);
    });
}
async function deleteProperty(id) {
    await fetch(`${API_BASE}/admin/delete_property/${id}`, { method: "DELETE" });
    alert("Property deleted!");
}
socket.on("new_property", data => {
    renderProperties([data]);
});