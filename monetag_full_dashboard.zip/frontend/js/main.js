const API_BASE = "http://localhost:5003";
const stripe = Stripe("pk_live_XXXXXXXXXXXXXXXXXXXX");
async function loadProperties() {
    const res = await fetch(`${API_BASE}/properties`);
    const properties = await res.json();
    renderProperties(properties);
}
loadProperties();
function renderProperties(properties) {
    const container = document.getElementById("property-list");
    container.innerHTML = "";
    properties.forEach(p => {
        const card = document.createElement("div");
        card.className = "bg-white p-4 rounded-xl shadow-md";
        card.innerHTML = `
            <img src="${p.image_url}" class="rounded-xl mb-2">
            <h3 class="font-bold text-lg">${p.title}</h3>
            <p class="text-gray-600">${p.location}</p>
            <p class="font-semibold">$${p.price}</p>
            <button class="bg-purple-600 text-white py-2 px-4 rounded mt-2" onclick="payProperty(${p.id}, ${p.price})">Buy</button>
        `;
        container.appendChild(card);
    });
}
async function payProperty(propertyId, amount) {
    const res = await fetch(`${API_BASE}/create_payment_intent`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ property_id: propertyId, amount })
    });
    const data = await res.json();
    const clientSecret = data.client_secret;
    const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: { card: {}, billing_details: { name: "Customer" } }
    });
    if (error) alert("Payment failed: " + error.message);
    else if (paymentIntent.status === "succeeded") alert("Payment successful! ✅");
}